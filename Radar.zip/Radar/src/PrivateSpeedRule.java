import java.util.Collections;
import java.util.List;

public class PrivateSpeedRule implements Rule {

    private static final int MAX_SPEED = 80;
    private static final double FEE = 300.0;

    @Override
    public String getName() {
        return "Private car speed limit";
    }

    @Override
    public List<Violation> evaluate(Observation observation) {
        if (observation.getCarType() == Observation.CarType.PRIVATE
                && observation.getSpeed() > MAX_SPEED) {
            String description = "speed of " + observation.getSpeed()
                    + " exceeded max allowed " + MAX_SPEED;
            return List.of(new Violation(getName(), description, FEE));
        }
        return Collections.emptyList();
    }
}
