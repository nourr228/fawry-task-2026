import java.util.Collections;
import java.util.List;

public class SeatbeltRule implements Rule {

    private static final double FEE = 100.0;

    @Override
    public String getName() {
        return "Seatbelt rule";
    }

    @Override
    public List<Violation> evaluate(Observation observation) {
        if (!observation.isSeatbeltFastened()) {
            return List.of(new Violation(getName(), "Seatbelt not fastned", FEE));
        }
        return Collections.emptyList();
    }
}
