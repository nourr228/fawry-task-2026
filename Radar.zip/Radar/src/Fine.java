import java.util.List;

public class Fine {

    private final String plateNumber;
    private final List<Violation> violations;
    private final double totalAmount;

    public Fine(String plateNumber, List<Violation> violations) {
        this.plateNumber = plateNumber;
        this.violations = violations;
        this.totalAmount = violations.stream().mapToDouble(Violation::getFee).sum();
    }

    public String getPlateNumber() {
        return plateNumber;
    }

    public List<Violation> getViolations() {
        return violations;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void print() {
        StringBuilder sb = new StringBuilder();
        sb.append("Traffic fine for car ").append(plateNumber).append(System.lineSeparator());
        sb.append("Total amount: ").append(formatAmount(totalAmount)).append(" EGP").append(System.lineSeparator());
        sb.append("Violations:").append(System.lineSeparator());
        for (Violation v : violations) {
            sb.append("- ").append(v.getDescription()).append(" : ")
              .append(formatAmount(v.getFee())).append(" EGP").append(System.lineSeparator());
        }
        System.out.print(sb);
    }

    private static String formatAmount(double amount) {
        if (amount == Math.floor(amount)) {
            return String.valueOf((long) amount);
        }
        return String.valueOf(amount);
    }
}
