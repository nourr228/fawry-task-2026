import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Radar {

    private final List<Rule> rules = new ArrayList<>();
    private final List<Fine> issuedFines = new ArrayList<>();
    private final Map<String, Integer> violationCountsByRule = new LinkedHashMap<>();

    public void addRule(Rule rule) {
        rules.add(rule);
    }

    public Fine processObservation(Observation observation) {
        List<Violation> violations = new ArrayList<>();

        for (Rule rule : rules) {
            List<Violation> ruleViolations = rule.evaluate(observation);
            violations.addAll(ruleViolations);
        }

        if (violations.isEmpty()) {
            return null;
        }

        for (Violation v : violations) {
            violationCountsByRule.merge(v.getRuleName(), 1, Integer::sum);
        }

        Fine fine = new Fine(observation.getPlateNumber(), violations);
        issuedFines.add(fine);
        return fine;
    }

    public Map<String, Double> getAllFines() {
        Map<String, Double> result = new LinkedHashMap<>();
        for (Fine fine : issuedFines) {
            result.merge(fine.getPlateNumber(), fine.getTotalAmount(), Double::sum);
        }
        return result;
    }

    public Map<String, Integer> getViolatedRulesWithCount() {
        return new LinkedHashMap<>(violationCountsByRule);
    }

    public List<Fine> getIssuedFines() {
        return new ArrayList<>(issuedFines);
    }
}
