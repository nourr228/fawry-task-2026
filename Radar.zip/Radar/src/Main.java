import java.time.LocalDate;
import java.util.Map;

public class Main {

    public static void main(String[] args) {

        Radar radar = new Radar();
        radar.addRule(new TruckSpeedRule());
        radar.addRule(new PrivateSpeedRule());
        radar.addRule(new SeatbeltRule());

        Observation[] observations = new Observation[] {

            new Observation("ABC1234", LocalDate.of(2026, 7, 23),
                    Observation.CarType.PRIVATE, 94, false),

            new Observation("XYZ9999", LocalDate.of(2026, 7, 23),
                    Observation.CarType.PRIVATE, 70, true),

            new Observation("TRK5551", LocalDate.of(2026, 7, 23),
                    Observation.CarType.TRUCK, 75, true),

            new Observation("BUS0007", LocalDate.of(2026, 7, 23),
                    Observation.CarType.BUS, 50, false),

            new Observation("ABC1234", LocalDate.of(2026, 7, 24),
                    Observation.CarType.PRIVATE, 100, true),
        };

        System.out.println("=== Processing observations ===");
        for (Observation obs : observations) {
            Fine fine = radar.processObservation(obs);
            if (fine != null) {
                fine.print();
                System.out.println();
            } else {
                System.out.println("Car " + obs.getPlateNumber() + ": no violations.");
                System.out.println();
            }
        }

        System.out.println("=== All fines (plate -> total amount) ===");
        for (Map.Entry<String, Double> entry : radar.getAllFines().entrySet()) {
            System.out.println(entry.getKey() + " : " + entry.getValue() + " EGP");
        }
        System.out.println();

        System.out.println("=== Violated rules (rule -> count) ===");
        for (Map.Entry<String, Integer> entry : radar.getViolatedRulesWithCount().entrySet()) {
            System.out.println(entry.getKey() + " : " + entry.getValue());
        }
    }
}
