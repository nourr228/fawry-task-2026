import java.util.Collections;
import java.util.List;

public class TruckSpeedRule implements Rule {

    private static final int MAX_SPEED = 60;
    private static final double FEE = 200.0;

    @Override
    public String getName() {
        return "Truck speed limit";
    }

    @Override
    public List<Violation> evaluate(Observation observation) {
        if (observation.getCarType() == Observation.CarType.TRUCK
                && observation.getSpeed() > MAX_SPEED) {
            double fee = FEE;
            String description = "speed of " + observation.getSpeed()
                    + " exceeded max allowed " + MAX_SPEED;
            return List.of(new Violation(getName(), description, fee));
        }
        return Collections.emptyList();
    }
}
